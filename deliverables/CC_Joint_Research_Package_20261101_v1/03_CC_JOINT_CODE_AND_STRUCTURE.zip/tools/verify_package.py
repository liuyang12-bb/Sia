from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parents[1]
hashes=json.loads((root/'provenance/source_hashes.json').read_text(encoding='utf-8'))
source=root/'workspace/cc-joint-core80-full-lex-repair-v8'
for name,h in hashes.items():
 p=source/name
 assert p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest().upper()==h.upper(),name
print('PASS:',len(hashes),'original source/input/test files match historical hashes; no simulation started.')
